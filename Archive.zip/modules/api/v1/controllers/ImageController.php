<?php

namespace app\modules\api\v1\controllers;

use yii\rest\ActiveController;

class ImageController extends ActiveController
{
    
    public $modelClass = 'app\modules\api\v1\models\Image';

}
