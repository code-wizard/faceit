<?php

return [
    'adminEmail' => 'amaefulacj@gmail.com',
];
